<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BookingController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/test', function() {return "Dag Gast ;)";});

Route::get('/rooms/{roomType?}', [\App\Http\Controllers\ShowRoomsController::class, '__invoke']);

Route::get('bookings', [App\Http\Controllers\BookingController::class])->name('bookings');

Route::resource('/bookings','\App\Http\Controllers\BookingController');

Route::get('/rooms', 'App\Http\Controllers\ShowRoomsController')->name('rooms');