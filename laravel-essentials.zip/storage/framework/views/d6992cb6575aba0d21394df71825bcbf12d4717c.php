

<?php $__env->startSection('content'); ?>
<table class="table">
    <thead>
        <tr>
            <th>
                Room Number
            </th>
            <th>
                Type
            </th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($room->number); ?>

                </td>
                <td>
                    <?php echo e($room->roomType->name); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/resources/views/rooms/index.blade.php ENDPATH**/ ?>