

<?php $__env->startSection('buttons'); ?>
<a class="btn btn-primary" href="<?php echo e(route('bookings.create')); ?>" role="button">
    Add New Booking</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Room</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Reservation?</th>
            <th>Paid?</th>
            <th>Started?</th>
            <th>Passed?</th>
            <th>Created</th>
            <th class="Actions">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($booking->id); ?></td>
            <td><?php echo e($booking->room->number); ?> <?php echo e($booking->room->roomType->name); ?></td>
            <td><?php echo e(date('F d, Y', strtotime($booking->start))); ?></td>
            <td><?php echo e(date('F d, Y', strtotime($booking->end))); ?></td>
            <td><?php echo e($booking->is_reservation ? 'Yes' : 'No'); ?></td>
            <td><?php echo e($booking->is_paid ? 'Yes' : 'No'); ?></td>
            <td><?php echo e((strtotime($booking->start) < time()) ? 'Yes' : 'No'); ?></td>
            <td><?php echo e((strtotime($booking->end) < time()) ? 'Yes' : 'No'); ?></td>
            <td><?php echo e(date('F d, Y', strtotime($booking->created_at))); ?></td>
            <td class="actions">
                <a href="<?php echo e(action('App\Http\Controllers\BookingController@show', ['booking' => $booking->id])); ?>" alt="View" title="View">
                    View
                </a>
                <a href="<?php echo e(action('App\Http\Controllers\BookingController@edit', ['booking' => $booking->id])); ?>" alt="Edit" title="Edit">
                    Edit
                </a>
                <form action="<?php echo e(action('App\Http\Controllers\BookingController@destroy', ['booking' => $booking->id])); ?>" method="POST">
                    <?php echo e(method_field('DELETE')); ?>

                    <?php echo e(csrf_field()); ?>

                    <button type="submit" class="btn btn-link" title="delete" value="delete">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($bookings->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/resources/views/bookings/index.blade.php ENDPATH**/ ?>